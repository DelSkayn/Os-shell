/*
 * Operating Systems assignment 1
 * Authors:
 * Mees delzenne s1531255.
 * Mick Voogt s1542125
 */

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

void start_shell();

